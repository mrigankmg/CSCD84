g++ -O3 -c -g MiniMax_search.c
g++ -O3 -g *.o -lm -lglut -lGL -lGLU -lX11 -o MiniMax_search

